console.log("Hello AzerType !");

const listeMots = ["Bonjour", "AzerType", "JavaScript", "OpenClassroom", "Formation", "Cachalot", "Developpement", "Informatique", "Programmation", "Code", "Pétunia", "Ordinateur", "Clavier", "Souris", "Ecran", "Internet", "Réseau", "Serveur", "Base de données", "Application", "Logiciel", "Serviette", "Stylo", "Cahier", "Bureau", "Chaise", "Lampe", "Téléphone", "Tablette", "Montre", "Vélo", "Voiture", "Avion", "Train", "Bateau", "Ville", "Village", "Pays", "Continent", "Océan", "Montagne", "Forêt", "Désert", "Rivière", "Lac", "Île", "Plage", "Soleil", "Lune", "Étoile"];
const listePhrases = ["Le chat dort sur le canapé.", "Il fait beau aujourd'hui.", "J'aime apprendre le JavaScript.", "La programmation est amusante.", "OpenClassroom est une excellente plateforme d'apprentissage."];
let score = 0;
let choixMode;
let motUtilisateur;
let phraseUtilisateur;
let indexMot;
let indexPhrase;

choixMode = prompt("Bienvenue dans AzerType !\n\nVoulez-vous taper des \"mots\" ou des \"phrases\" ?");

if (choixMode === "mots") {
    for (indexMot = 0; indexMot < listeMots.length; indexMot++) {
            motUtilisateur = prompt("Bienvenue dans AzerType !\n\nTapez \"" + listeMots[indexMot] + "\" le plus rapidement possible.");

        if (motUtilisateur === listeMots[indexMot]) {
            score++;
            console.log("Bravo ! Votre score est de " + score + ".");
        } else if (motUtilisateur === "BREAK") {
            break;
        } else {
            console.log("Mauvais mot.");
        }
    }
} else if (choixMode === "phrases") {
    for (indexPhrase = 0; indexPhrase < listePhrases.length; indexPhrase++) {
        phraseUtilisateur = prompt("Bienvenue dans AzerType !\n\nTapez la phrase suivante le plus rapidement possible :\n\n\"" + listePhrases[indexPhrase] + "\"");

        if (phraseUtilisateur === listePhrases[indexPhrase]) {
            score++;
            console.log("Bravo ! Votre score est de " + score + ".");
        } else if (phraseUtilisateur === "BREAK") {
            break;
        } else {
            console.log("Mauvaise phrase.");
        }
    }
}

console.log("Votre score final est de " + score + " sur " + listeMots.length + ".");